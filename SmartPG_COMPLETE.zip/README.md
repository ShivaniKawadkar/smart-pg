# Smart PG

A React + Vite frontend with a FastAPI + SQLAlchemy + SQLite backend for finding and managing PG, Hostel, Co-Living and Flat listings.

## Features
- Simple local login
- PG / Hostel / Co-Living / Flat category-first search
- Location search using OpenStreetMap Nominatim
- Real mapped accommodation search using OpenStreetMap/Overpass
- GPS / reverse geocoding
- Saved property CRUD
- Boys / Girls / Unisex and Veg / Non-Veg filters
- Rent filtering
- Map and directions buttons
- Lost / robbed / stolen item incident reporting saved locally

## Run backend

```bash
python -m venv venv
# Windows PowerShell
venv\\Scripts\\Activate.ps1
# or Command Prompt
venv\\Scripts\\activate.bat

pip install -r requirements.txt
uvicorn main:app --reload
```

Backend: http://127.0.0.1:8000
Docs: http://127.0.0.1:8000/docs

## Run frontend

```bash
cd frontend
npm install
npm run dev
```

Frontend: http://127.0.0.1:5173

## Notes
- The frontend is configured for the backend at `http://127.0.0.1:8000`.
- Map search uses public OpenStreetMap services. Availability and tags depend on public map data.
- Map listings do not invent rent; when public map data has no rent, the UI shows that rent is unavailable.
